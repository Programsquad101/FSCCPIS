$(document).ready(function(){

    $("#student-btn").click(function(){
      $("#student").show();
      $("#faculty").hide();
      $("#tutor").hide();
      document.getElementById("student-btn").style.backgroundColor = "#fff";
      document.getElementById("faculty-btn").style.backgroundColor = "#eeeeee";
      document.getElementById("tutor-btn").style.backgroundColor = "#eeeeee";

      
    });
  
    $("#faculty-btn").click(function(){
      $("#student").hide();
      $("#faculty").show();
      $("#tutor").hide();
      document.getElementById("student-btn").style.backgroundColor = "#eeeeee";
      document.getElementById("faculty-btn").style.backgroundColor ="#fff";
      document.getElementById("tutor-btn").style.backgroundColor = "#eeeeee";
    });
  
    $("#tutor-btn").click(function(){
      $("#student").hide();
      $("#faculty").hide();
      $("#tutor").show();
      document.getElementById("student-btn").style.backgroundColor = "#eeeeee";
      document.getElementById("faculty-btn").style.backgroundColor = "#eeeeee";
      document.getElementById("tutor-btn").style.backgroundColor = "#fff";

       
    });
  
  
  });
  